<div class="top-bar d-none d-lg-block d-xl-block">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo e(_t('View in')); ?>

          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <?php $__currentLoopData = Cache::get('language'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="dropdown-item" href="<?php echo e(route($language['route'])); ?>"><?php echo e($language['language']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
      <div class="col-md-6 d-flex justify-content-end">
        <a href="/" class="btn btn-link" >
          <?php echo e(_t('Suggest a kid')); ?>

        </a>
        <a class="btn btn-success" href="/">
          <i class="fa fa-heart"></i> <?php echo e(_t('Volunteer')); ?>

        </a>
      </div>
    </div>
  </div>
</div>
<header class="xs-header-height xs-menu-style-border fundpress-header-main-version xs-menu-style-solid color-navy-blue">
  <div class="container">
    <nav class="xs-menus fundpress-menu">
      <div class="nav-header">
        <div class="nav-toggle"></div>
        <a class="nav-brand nav-logo" href="/">
          <img src="<?php echo e(asset('img/logo.png')); ?>" alt="<?php echo e(_t('Pascal Rufi Soccer Foundation')); ?>">
        </a>
      </div><!-- . END -->
      <div class="nav-menus-wrapper">
        <div class="xs-logo-wraper">
          <a class="nav-brand xs-logo fundpress-logo-v1" href="/">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="<?php echo e(_t('Pascal Rufi Soccer Foundation')); ?>">
          </a>
        </div>
        <ul class="nav-menu">
          <li><a href="#"><?php echo e(_t('Foundation')); ?></a>
            <ul class="nav-dropdown">
              <li><a href="/"><?php echo e(_t('About Us')); ?></a></li>
              <li><a href="/"><?php echo e(_t('Our Objective')); ?></a></li>
              <li><a href="/"><?php echo e(_t('Sponsors')); ?></a></li>
            </ul>
          </li>
          <li><a href="/"><?php echo e(_t('Sports')); ?></a>
            <ul class="nav-dropdown">
              <li><a href="/"><?php echo e(_t('Tennis')); ?></a>
                <ul class="nav-dropdown">
                  <li><a href="/"><?php echo e(_t('Athletes')); ?></a></li>
                  <li><a href="/"><?php echo e(_t('Suggest a talented kid')); ?></a></li>
                </ul>
              </li>
              <li><a href="/"><?php echo e(_t('Football')); ?></a>
                <ul class="nav-dropdown">
                  <li><a href="/"><?php echo e(_t('Athletes')); ?></a></li>
                  <li><a href="/"><?php echo e(_t('Suggest a talented kid')); ?></a></li>
                </ul>
              </li>
              <li><a href="/"><?php echo e(_t('Basket Ball')); ?></a>
                <ul class="nav-dropdown">
                  <li><a href="/"><?php echo e(_t('Athletes')); ?></a></li>
                  <li><a href="/"><?php echo e(_t('Suggest a talented kid')); ?></a></li>
                </ul>
              </li>
              <li><a href="/"><?php echo e(_t('Lawn Tennis')); ?></a>
                <ul class="nav-dropdown">
                  <li><a href="/"><?php echo e(_t('Athletes')); ?></a></li>
                  <li><a href="/"><?php echo e(_t('Suggest a talented kid')); ?></a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="/"><?php echo e(_t('Events')); ?></a></li>
          <li><a href="/"><?php echo e(_t('Voluteer')); ?></a>
            <ul class="nav-dropdown">
              <li><a href="/"><?php echo e(_t('Volunteer to Train')); ?></a></li>
              <li><a href="/"><?php echo e(_t('Volunteer to Support')); ?></a></li>
            </ul>
          </li>
          <li><a href="/"><?php echo e(_t('News')); ?></a></li>
          <li><a href="#"><?php echo e(_t("Emma's Blog")); ?></a></li>
          <li><a href="/"><?php echo e(_t('Contact')); ?></a></li>
        </ul>
        <div class="xs-navs-button d-block d-sm-block d-md-lock d-lg-none d-xl-none">
          <ul class="xs-icon-with-text fundpress-icon-menu">
            <li ><a href="#"  ><?php echo e(_t('Suggest a kid')); ?></a></li>
            <li ><a href="#" class="xs-btn round-btn green-btn"><i class="fa fa-heart"></i> <?php echo e(_t('Volunteer')); ?></a></li>
            <li >
              <div class="dropdown">
                <button class="btn btn-lg btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(_t('View in')); ?>

                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <?php $__currentLoopData = Cache::get('language'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href="<?php echo e(route($language['route'])); ?>"><?php echo e($language['language']); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div><!-- .nav-menus-wrapper END -->
    </nav><!-- .xs-menus .fundpress-menu END -->
  </div>
</header>
