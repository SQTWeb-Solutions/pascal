
<?php $__env->startSection('title'); ?>
  Welcome Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('pages.home.partials.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.atheletes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.callout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.mission', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.value', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('pages.home.partials.event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>