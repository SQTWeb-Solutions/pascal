<section class="xs-screen-height xs-welcome-section xs-bg fundpress-welcome-section">
  <div class="xs-banner-slider owl-carousel">
    <div class="xs-banner-slider-item" style="background-image: url(<?php echo e(asset('img/slider/slider1.jpg')); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="xs-welcome-content version-3">
              <div class="xs-welcome-wraper">
                <h2>Harneshing the inner talents.</h2>
                <div class="xs-btn-wraper">
                  <a href="#" class="xs-btn navy-blue-btn round-btn">see atheletes</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="xs-banner-slider-item" style="background-image: url(<?php echo e(asset('img/slider/slider2.jpg')); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="xs-welcome-content version-3">
              <div class="xs-welcome-wraper">
                <h2>Encourage young people with sports.</h2>
                <div class="xs-btn-wraper">
                  <a href="#" class="xs-btn navy-blue-btn round-btn">suggest a talented kid</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="xs-banner-slider-item" style="background-image: url(<?php echo e(asset('img/slider/slider3.jpg')); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="xs-welcome-content version-3">
              <div class="xs-welcome-wraper">
                <h2>Inspire participation in sports.</h2>
                <div class="xs-btn-wraper">
                  <a href="#" class="xs-btn navy-blue-btn round-btn">Volunteer now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
