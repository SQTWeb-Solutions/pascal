<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// change the language route
Route::get('/lang/en', 'LanguageController@english')->name('language.english');
Route::get('/lang/es', 'LanguageController@spanish')->name('language.spanish');
Route::get('/lang/fr', 'LanguageController@french')->name('language.french');

Route::group(['prefix' => Translation::getRoutePrefix(), 'middleware' => ['locale']], function()
{
  // Static pages route and website route
  Route::get('/', 'HomeController@index')->name('index');
});
