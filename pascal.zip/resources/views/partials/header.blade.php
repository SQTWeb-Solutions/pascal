<div class="top-bar d-none d-lg-block d-xl-block">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{ _t('View in') }}
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            @foreach (Cache::get('language') as $language)
              <a class="dropdown-item" href="{{route($language['route'])}}">{{ $language['language'] }}</a>
            @endforeach
          </div>
        </div>
      </div>
      <div class="col-md-6 d-flex justify-content-end">
        <a href="/" class="btn btn-link" >
          {{ _t('Suggest a kid')}}
        </a>
        <a class="btn btn-success" href="/">
          <i class="fa fa-heart"></i> {{ _t('Volunteer')}}
        </a>
      </div>
    </div>
  </div>
</div>
<header class="xs-header-height xs-menu-style-border fundpress-header-main-version xs-menu-style-solid color-navy-blue">
  <div class="container">
    <nav class="xs-menus fundpress-menu">
      <div class="nav-header">
        <div class="nav-toggle"></div>
        <a class="nav-brand nav-logo" href="/">
          <img src="{{asset('img/logo.png')}}" alt="{{ _t('Pascal Rufi Soccer Foundation')}}">
        </a>
      </div><!-- . END -->
      <div class="nav-menus-wrapper">
        <div class="xs-logo-wraper">
          <a class="nav-brand xs-logo fundpress-logo-v1" href="/">
            <img src="{{asset('img/logo.png')}}" alt="{{ _t('Pascal Rufi Soccer Foundation')}}">
          </a>
        </div>
        <ul class="nav-menu">
          <li><a href="#">{{ _t('Foundation')}}</a>
            <ul class="nav-dropdown">
              <li><a href="/">{{ _t('About Us')}}</a></li>
              <li><a href="/">{{ _t('Our Objective')}}</a></li>
              <li><a href="/">{{ _t('Sponsors')}}</a></li>
            </ul>
          </li>
          <li><a href="/">{{ _t('Sports')}}</a>
            <ul class="nav-dropdown">
              <li><a href="/">{{ _t('Tennis')}}</a>
                <ul class="nav-dropdown">
                  <li><a href="/">{{ _t('Athletes')}}</a></li>
                  <li><a href="/">{{ _t('Suggest a talented kid')}}</a></li>
                </ul>
              </li>
              <li><a href="/">{{ _t('Football')}}</a>
                <ul class="nav-dropdown">
                  <li><a href="/">{{ _t('Athletes')}}</a></li>
                  <li><a href="/">{{ _t('Suggest a talented kid')}}</a></li>
                </ul>
              </li>
              <li><a href="/">{{ _t('Basket Ball')}}</a>
                <ul class="nav-dropdown">
                  <li><a href="/">{{ _t('Athletes')}}</a></li>
                  <li><a href="/">{{ _t('Suggest a talented kid')}}</a></li>
                </ul>
              </li>
              <li><a href="/">{{ _t('Lawn Tennis')}}</a>
                <ul class="nav-dropdown">
                  <li><a href="/">{{ _t('Athletes')}}</a></li>
                  <li><a href="/">{{ _t('Suggest a talented kid')}}</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="/">{{ _t('Events')}}</a></li>
          <li><a href="/">{{ _t('Voluteer')}}</a>
            <ul class="nav-dropdown">
              <li><a href="/">{{ _t('Volunteer to Train')}}</a></li>
              <li><a href="/">{{ _t('Volunteer to Support')}}</a></li>
            </ul>
          </li>
          <li><a href="/">{{ _t('News')}}</a></li>
          <li><a href="#">{{ _t("Emma's Blog")}}</a></li>
          <li><a href="/">{{ _t('Contact')}}</a></li>
        </ul>
        <div class="xs-navs-button d-block d-sm-block d-md-lock d-lg-none d-xl-none">
          <ul class="xs-icon-with-text fundpress-icon-menu">
            <li ><a href="#"  >{{ _t('Suggest a kid')}}</a></li>
            <li ><a href="#" class="xs-btn round-btn green-btn"><i class="fa fa-heart"></i> {{ _t('Volunteer')}}</a></li>
            <li >
              <div class="dropdown">
                <button class="btn btn-lg btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  {{ _t('View in') }}
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  @foreach (Cache::get('language') as $language)
                    <a class="dropdown-item" href="{{route($language['route'])}}">{{ $language['language'] }}</a>
                  @endforeach
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div><!-- .nav-menus-wrapper END -->
    </nav><!-- .xs-menus .fundpress-menu END -->
  </div>
</header>
